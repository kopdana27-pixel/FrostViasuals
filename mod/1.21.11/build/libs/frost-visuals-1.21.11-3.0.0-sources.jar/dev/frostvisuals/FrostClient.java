package dev.frostvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public final class FrostClient implements ClientModInitializer {
    private static class_304 menu;
    private static boolean fps = true, coords = true, direction = true;
    private static boolean ping = true, moduleList = true;

    @Override
    public void onInitializeClient() {
        class_304.class_11900 category = class_304.class_11900.method_74698(
            class_2960.method_60655("frostvisuals", "main")
        );
        menu = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.frostvisuals.menu", class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT, category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menu.method_1436()) {
                if (client.field_1724 != null) client.method_1507(new FrostMenu());
            }
        });

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1687 == null) return;

            int lines = (fps ? 1 : 0) + (coords ? 1 : 0) +
                        (direction ? 1 : 0) + (ping ? 1 : 0);
            int modules = moduleList ? 5 : 0;
            if (lines + modules == 0) return;

            graphics.method_25294(5, 5, 205, 12 + (lines + modules) * 14, 0x990D1522);
            graphics.method_25294(5, 5, 205, 7, 0xFF65D9FF);
            int y = 12;

            if (fps) {
                graphics.method_27535(client.field_1772,
                    class_2561.method_43470("FROST  |  FPS: " + client.method_47599()),
                    10, y, 0xFF9DEBFF);
                y += 14;
            }
            if (ping) {
                var connection = client.method_1562();
                var info = connection == null ? null :
                    connection.method_2871(client.field_1724.method_5667());
                String value = info == null ? "--" : info.method_2959() + " ms";
                graphics.method_27535(client.field_1772,
                    class_2561.method_43470("PING: " + value), 10, y, 0xFFB9C8FF);
                y += 14;
            }
            if (coords) {
                String xyz = String.format("XYZ: %.1f  %.1f  %.1f",
                    client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
                graphics.method_27535(client.field_1772, class_2561.method_43470(xyz),
                    10, y, 0xFFFFFFFF);
                y += 14;
            }
            if (direction) {
                graphics.method_27535(client.field_1772,
                    class_2561.method_43470("Yaw: " + Math.round(client.field_1724.method_36454()) + "°"),
                    10, y, 0xFFB9C8FF);
                y += 14;
            }
            if (moduleList) {
                String[] names = {
                    "Frost HUD", "FPS Counter", "Coordinates",
                    "Direction", "Ping Display"
                };
                for (String name : names) {
                    graphics.method_27535(client.field_1772,
                        class_2561.method_43470("• " + name), 10, y, 0xFF65D9FF);
                    y += 14;
                }
            }
        });
    }

    public static class FrostMenu extends class_437 {
        protected FrostMenu() { super(class_2561.method_43470("FROST VISUALS")); }

        private class_2561 label(String name, boolean enabled) {
            return class_2561.method_43470(name + ": " + (enabled ? "ВКЛ" : "ВЫКЛ"));
        }

        @Override
        protected void method_25426() {
            int x = field_22789 / 2 - 100;
            int y = field_22790 / 2 - 105;
            method_37063(class_4185.method_46430(label("FPS", fps), b -> {
                fps = !fps; b.method_25355(label("FPS", fps));
            }).method_46434(x, y, 200, 22).method_46431());
            method_37063(class_4185.method_46430(label("Ping", ping), b -> {
                ping = !ping; b.method_25355(label("Ping", ping));
            }).method_46434(x, y + 27, 200, 22).method_46431());
            method_37063(class_4185.method_46430(label("Координаты", coords), b -> {
                coords = !coords; b.method_25355(label("Координаты", coords));
            }).method_46434(x, y + 54, 200, 22).method_46431());
            method_37063(class_4185.method_46430(label("Направление", direction), b -> {
                direction = !direction; b.method_25355(label("Направление", direction));
            }).method_46434(x, y + 81, 200, 22).method_46431());
            method_37063(class_4185.method_46430(label("Module List", moduleList), b -> {
                moduleList = !moduleList; b.method_25355(label("Module List", moduleList));
            }).method_46434(x, y + 108, 200, 22).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Закрыть"), b -> method_25419())
                .method_46434(x, y + 139, 200, 22).method_46431());
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            method_25420(graphics, mouseX, mouseY, partialTick);
            graphics.method_25294(field_22789 / 2 - 125, field_22790 / 2 - 135,
                field_22789 / 2 + 125, field_22790 / 2 + 105, 0xEE101722);
            graphics.method_25294(field_22789 / 2 - 125, field_22790 / 2 - 135,
                field_22789 / 2 + 125, field_22790 / 2 - 132, 0xFF65D9FF);
            graphics.method_27534(field_22793, class_2561.method_43470("FROST VISUALS"),
                field_22789 / 2, field_22790 / 2 - 120, 0xFFBDEEFF);
            super.method_25394(graphics, mouseX, mouseY, partialTick);
        }

        @Override
        public boolean method_25421() { return false; }
    }
}
